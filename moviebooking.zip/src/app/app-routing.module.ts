import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./component/home/home.component";
import { MovieComponent } from "./component/movie/movie.component";
import { MoviesComponent } from "./component/movies/movies.component";
import { AdminComponent } from "./component/admin/admin.component";
import { AdminMovieEventComponent } from "./component/admin-movie-event/admin-movie-event.component";
import { AdminCinemaComponent } from "./component/admin-cinema/admin-cinema.component";
import { AdminMovieComponent } from "./component/admin-movie/admin-movie.component";

const routes: Routes = [
  { path: "", redirectTo: "/home", pathMatch: "full" },
  { path: "home", component: HomeComponent },
  { path: "movies", component: MoviesComponent },
  { path: "movies/:id", component: MovieComponent },
  { path: "admin", component: AdminComponent },
  { path: "admin/movie", component: AdminMovieComponent },
  { path: "admin/cinema", component: AdminCinemaComponent },
  { path: "admin/movieEvent", component: AdminMovieEventComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
