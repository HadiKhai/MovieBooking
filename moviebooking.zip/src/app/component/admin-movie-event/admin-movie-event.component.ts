import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-movie-event',
  templateUrl: './admin-movie-event.component.html',
  styleUrls: ['./admin-movie-event.component.css']
})
export class AdminMovieEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
