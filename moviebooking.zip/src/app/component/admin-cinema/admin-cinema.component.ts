import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-cinema',
  templateUrl: './admin-cinema.component.html',
  styleUrls: ['./admin-cinema.component.css']
})
export class AdminCinemaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
