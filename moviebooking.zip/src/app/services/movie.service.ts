import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class MovieService {
  private moviesUrl = "api/movies";
  constructor(private http: HttpClient) {}

  getMovies() {
    return this.http.get("server/admin/movies");
  }
  getMovie(id: number) {
    return this.http.get("server/admin/movies/" + id);
  }

  createMovie(movie) {
    let body = JSON.stringify(movie);
    return this.http.post("/server/admin/movies", body, httpOptions);
  }
  deleteMovie(id: number) {
    return this.http.delete("/server/admin/movies/" + id);
  }
}
